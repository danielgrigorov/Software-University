﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface Idable
    {
        public string Id { get; set; }
    }
}
