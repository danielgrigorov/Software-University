﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IAgeable
    {
        public int Age { get; set; }
    }
}
