﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telepony
{
    public interface ICallable
    {
        void Calling(string number);
    }
}
