﻿

using Farm;

namespace _01._Single_Inheritance
{
    public class Cat : Animal
    {
        public void Meow()
        {
            System.Console.WriteLine("meowing...");
        }
    }
}
