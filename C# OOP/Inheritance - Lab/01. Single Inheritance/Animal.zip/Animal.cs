﻿using System;

namespace Farm
{
    public abstract class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
