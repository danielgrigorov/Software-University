﻿using System;

namespace _01._Single_Inheritance
{
    public class Puppy 
    {
        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
}
