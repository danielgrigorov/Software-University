﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(int horsepower, double fuel)
            : base (horsepower, fuel)
        {

        }
    }
}
