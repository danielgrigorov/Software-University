﻿namespace EasterRaces.Repositories.Entities
{
    public interface IRepository
    {
    }
}