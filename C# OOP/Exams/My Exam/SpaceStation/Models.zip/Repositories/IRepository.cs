﻿namespace SpaceStation.Repositories
{
    public interface IRepository
    {
    }
}